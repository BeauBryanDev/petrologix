"""Inference API for the Petrologix lithology classifier.

Intended caller: a backend service that receives a well-log CSV (typically a
lasio-converted LAS file) and needs lithology predictions per depth sample.

    from petrologix import predict_lithology, to_intervals, check_distribution
    result = predict_lithology("uploaded_well.csv")

`result` is a DataFrame with one row per input row:
    DEPTH_MD | lithology_code | lithology_name | confidence

Design notes
------------
* Feature engineering here MUST match training exactly. It uses petrologix.features,
  the same module the ETL pipeline uses, and deliberately does NOT call
  `add_categorical_encoding` -- GROUP/FORMATION are not model features (they do
  not exist in LAS files) and that function also rewrites a shared encoder file.
* Column order is enforced from the bundle's `feature_list`, because the model
  does not validate feature names -- a reordered frame yields silently wrong
  predictions rather than an error.
* Missing OPTIONAL curves are inserted as NaN on purpose: XGBoost has native
  missing-value handling and the model was trained with those gaps present.
  Missing REQUIRED curves raise, because a prediction without them is not
  trustworthy and silence would be the worst outcome for an agent.
"""
from pathlib import Path
from typing import Union

import joblib
import numpy as np
import pandas as pd

from petrologix.config import (
    ACTIVE_MODEL_VERSION,
    LAS_NULL,
    MODELS_DIR,
    NULL_SENTINEL_FLOOR,
    RENAME_MAP,
)
from petrologix.features import (
    add_normalized_depth,
    add_resistivity_ratios,
    add_rolling_stats,
)

# Versioned artifacts: models/<version>/lithology_model.pkl. Switch which model
# the agent serves by changing ACTIVE_MODEL_VERSION in petrologix/config.py; older
# versions stay on disk and loadable by passing an explicit path to load_bundle().
BUNDLE_PATH = MODELS_DIR / ACTIVE_MODEL_VERSION / "lithology_model.pkl"

_BUNDLE = None


class MissingCurvesError(ValueError):
    """Raised when an uploaded CSV lacks curves the model requires."""


def load_bundle(path: Union[str, Path] = BUNDLE_PATH, force_reload: bool = False) -> dict:
    """Load (and memoize) the joblib inference bundle."""
    global _BUNDLE
    if _BUNDLE is None or force_reload:
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(
                f"No model bundle at {path}. Train one with `python train.py`, or set "
                f"PETROLOGIX_MODELS_DIR to a directory containing <version>/lithology_model.pkl."
            )
        _BUNDLE = joblib.load(path)
    return _BUNDLE


def _read_input(source: Union[str, Path, pd.DataFrame]) -> pd.DataFrame:
    if isinstance(source, pd.DataFrame):
        return source.copy()
    return pd.read_csv(source)


def prepare_features(source: Union[str, Path, pd.DataFrame], bundle: dict = None) -> pd.DataFrame:
    """Turn a raw well-log CSV/DataFrame into the exact model feature matrix.

    Returns a frame indexed like the input, with columns == bundle['feature_list'].
    """
    bundle = bundle or load_bundle()
    df = _read_input(source)

    # --- schema normalization (mirrors transform/normalize.py) ---------------
    # Files carrying both DEPT and DEPTH_MD would collide on rename; DEPT wins,
    # matching the ETL pipeline's choice.
    if "DEPT" in df.columns and "DEPTH_MD" in df.columns:
        df = df.drop(columns=["DEPTH_MD"])
    df = df.rename(columns=RENAME_MAP)

    if "DEPTH_MD" not in df.columns:
        raise MissingCurvesError(
            "input has no depth column: expected 'DEPTH_MD' or 'DEPT'."
        )

    missing_required = [c for c in bundle["required_curves"] if c not in df.columns]
    if missing_required:
        raise MissingCurvesError(
            f"input is missing required curves: {missing_required}. "
            f"Required: {bundle['required_curves']}. "
            f"Optional (filled as NaN if absent): {bundle['optional_curves']}."
        )

    # Optional curves absent from this well become NaN -- the state the model was
    # trained to expect for wells that never ran those tools.
    for col in bundle["optional_curves"]:
        if col not in df.columns:
            df[col] = np.nan

    numeric_cols = bundle["required_curves"] + bundle["optional_curves"] + ["DEPTH_MD"]
    for col in numeric_cols:
        df[col] = pd.to_numeric(df[col], errors="coerce").replace(LAS_NULL, np.nan)

    # Undeclared NULL sentinels and filter artifacts, matching the ingest path
    # (petrologix.config.NULL_SENTINEL_FLOOR). This MUST mirror training: if an
    # upload keeps -999.9 as a real RXO value while the training data had it
    # stripped, inference sees a distribution the model never learned. Depth is
    # excluded -- only log curves are floored.
    curve_cols = bundle["required_curves"] + bundle["optional_curves"]
    df[curve_cols] = df[curve_cols].mask(df[curve_cols] < NULL_SENTINEL_FLOOR)

    # --- feature engineering (same functions as the training pipeline) -------
    # The rolling/zscore transforms group by WELL; a single uploaded well still
    # needs the column present. If the CSV carries a real WELL value we keep it,
    # so a multi-well file is handled correctly too.
    if "WELL" not in df.columns:
        df["WELL"] = "__uploaded__"
    df["WELL"] = df["WELL"].fillna("__uploaded__")

    df = add_resistivity_ratios(df)
    df = add_rolling_stats(df)   # sorts by (WELL, DEPTH_MD) -- see note in predict_lithology
    df = add_normalized_depth(df)

    return df


def predict_lithology(
    source: Union[str, Path, pd.DataFrame],
    bundle: dict = None,
    include_probabilities: bool = False,
) -> pd.DataFrame:
    """Predict lithology per depth sample for one uploaded well log.

    Parameters
    ----------
    source : path to a CSV, or an already-loaded DataFrame.
    include_probabilities : also return one column per class with its probability.

    Returns
    -------
    DataFrame with WELL, DEPTH_MD, lithology_code (FORCE 2020), lithology_name,
    confidence (max class probability), sorted by depth.
    """
    bundle = bundle or load_bundle()
    prepared = prepare_features(source, bundle)

    X = prepared[bundle["feature_list"]]
    proba = bundle["model"].predict_proba(X)
    idx = proba.argmax(axis=1)

    codes = np.asarray(bundle["classes_force_code"])
    names = np.asarray(bundle["classes_name"])

    out = pd.DataFrame(
        {
            "WELL": prepared["WELL"].values,
            "DEPTH_MD": prepared["DEPTH_MD"].values,
            "lithology_code": codes[idx],
            "lithology_name": names[idx],
            "confidence": proba.max(axis=1),
        }
    )
    if include_probabilities:
        for i, name in enumerate(bundle["classes_name"]):
            out[f"proba_{name}"] = proba[:, i]

    # add_rolling_stats already sorted by (WELL, DEPTH_MD); make that explicit so
    # the returned order is a documented guarantee rather than an implementation
    # detail of an upstream transform.
    return out.sort_values(["WELL", "DEPTH_MD"]).reset_index(drop=True)


def to_intervals(
    result: pd.DataFrame,
    min_thickness: float = 0.5,
    merge_thin: bool = True,
) -> pd.DataFrame:
    """Collapse per-sample predictions into lithology intervals.

    A typical well returns ~10,000 rows at 0.15 m sampling. That is far too much
    to put in an LLM context and is not what a petrophysicist reads anyway -- they
    read zones. This run-length-encodes consecutive same-lithology samples into
    intervals, typically reducing 10,000 rows to 50-200.

    Parameters
    ----------
    min_thickness : intervals thinner than this (metres) are dropped or merged.
        At 0.15 m sampling, 0.5 m is ~3 samples -- below the resolution most
        logging tools can actually resolve a bed at.
    merge_thin : when True, a dropped thin interval is absorbed into the thicker
        of its two neighbours instead of leaving a depth gap. When False, thin
        intervals are simply removed and the output has gaps.

    Returns
    -------
    DataFrame[WELL, top, base, thickness, lithology_code, lithology_name,
              confidence, n_samples] sorted by depth.
    """
    if result.empty:
        return pd.DataFrame(columns=["WELL", "top", "base", "thickness",
                                     "lithology_code", "lithology_name",
                                     "confidence", "n_samples"])

    out = []
    for well, wdf in result.groupby("WELL", sort=False):
        wdf = wdf.sort_values("DEPTH_MD")
        # New run whenever the predicted class changes going down the hole.
        run_id = (wdf["lithology_code"] != wdf["lithology_code"].shift()).cumsum()
        zones = wdf.groupby(run_id).agg(
            top=("DEPTH_MD", "first"),
            base=("DEPTH_MD", "last"),
            lithology_code=("lithology_code", "first"),
            lithology_name=("lithology_name", "first"),
            confidence=("confidence", "mean"),
            n_samples=("DEPTH_MD", "size"),
        )
        zones.insert(0, "WELL", well)
        zones["thickness"] = zones["base"] - zones["top"]

        if merge_thin and len(zones) > 1:
            # Absorb thin zones into the thicker neighbour, repeatedly: removing
            # one thin zone can make its neighbours adjacent and mergeable, so a
            # single pass would leave fragments behind.
            keep = zones[zones["thickness"] >= min_thickness]
            if keep.empty:
                # Whole well is thinner than min_thickness -- return it unsplit
                # rather than nothing, so the caller still gets an answer.
                keep = zones.loc[[zones["thickness"].idxmax()]]
            zones = keep
            # Re-merge runs that became adjacent and share a lithology.
            regroup = (zones["lithology_code"] != zones["lithology_code"].shift()).cumsum()
            zones = zones.groupby(regroup).agg(
                WELL=("WELL", "first"),
                top=("top", "first"),
                base=("base", "last"),
                lithology_code=("lithology_code", "first"),
                lithology_name=("lithology_name", "first"),
                confidence=("confidence", "mean"),
                n_samples=("n_samples", "sum"),
            )
            zones["thickness"] = zones["base"] - zones["top"]
        else:
            zones = zones[zones["thickness"] >= min_thickness]

        out.append(zones)

    cols = ["WELL", "top", "base", "thickness", "lithology_code",
            "lithology_name", "confidence", "n_samples"]
    return (pd.concat(out, ignore_index=True)[cols]
            .sort_values(["WELL", "top"])
            .reset_index(drop=True))


# Fraction of a curve's values allowed outside the training p01-p99 band before
# that curve is called out-of-distribution. An in-distribution well sits near 2%
# by construction; 20% is well clear of normal per-well variation.
OOD_CURVE_THRESHOLD = 0.20


def check_distribution(source, bundle: dict = None) -> dict:
    """Check whether an uploaded well resembles the wells the model was trained on.

    The model saw 118 Norwegian Continental Shelf wells. Given a well from a
    different basin, tool vendor, or logging era it will still return confident
    predictions -- silently wrong ones. This compares each curve against the
    training p01-p99 band and reports how far outside it the upload sits.

    This is a distribution check, NOT a physical-plausibility check: a reading can
    be perfectly valid and still be something the model has never seen.

    Returns
    -------
    dict with:
      status   : "ok" | "warning" | "out_of_distribution"
      message  : one-line human/agent-readable summary
      curves   : per-curve {fraction_outside, training_range, well_median, flagged}
      flagged_required / flagged_optional : lists of curve names
      missing_required : required curves absent or entirely null
    """
    bundle = bundle or load_bundle()
    stats = bundle.get("training_curve_stats")
    if not stats:
        return {"status": "unknown", "message": "model bundle carries no training "
                "curve statistics; cannot assess distribution.", "curves": {}}

    df = prepare_features(source, bundle)

    curves, flagged_req, flagged_opt, missing_req = {}, [], [], []
    for curve, ref in stats.items():
        series = df[curve].dropna() if curve in df.columns else pd.Series(dtype=float)
        required = curve in bundle["required_curves"]
        if series.empty:
            if required:
                missing_req.append(curve)
            continue
        outside = float(((series < ref["p01"]) | (series > ref["p99"])).mean())
        flagged = outside > OOD_CURVE_THRESHOLD
        curves[curve] = {
            "fraction_outside": round(outside, 4),
            "training_range": [round(ref["p01"], 3), round(ref["p99"], 3)],
            "well_median": round(float(series.median()), 3),
            "training_median": round(ref["p50"], 3),
            "flagged": flagged,
        }
        if flagged:
            (flagged_req if required else flagged_opt).append(curve)

    # Required curves carry the verdict: they are present in >=90% of training
    # wells, so a mismatch there means the log itself is unfamiliar. Optional
    # curves are sparse in training and noisier, so they inform but don't decide.
    if missing_req or len(flagged_req) >= 3:
        status = "out_of_distribution"
    elif flagged_req:
        status = "warning"
    else:
        status = "ok"

    if status == "ok":
        message = ("Well resembles the training data (118 Norwegian Continental "
                   "Shelf wells). Predictions can be interpreted normally.")
    elif status == "warning":
        message = (f"{', '.join(flagged_req)} sits outside the training range. "
                   "Predictions may be less reliable than the reported confidence "
                   "suggests; treat them as provisional.")
    else:
        parts = []
        if missing_req:
            parts.append(f"required curve(s) {', '.join(missing_req)} are empty")
        if len(flagged_req) >= 3:
            parts.append(f"{len(flagged_req)} required curves "
                         f"({', '.join(flagged_req)}) sit outside the training range")
        message = ("This well does not resemble the training data (" +
                   "; ".join(parts) + "). The model was trained only on Norwegian "
                   "Continental Shelf wells and its predictions here are unreliable "
                   "regardless of the confidence values it reports.")

    return {
        "status": status,
        "message": message,
        "curves": curves,
        "flagged_required": flagged_req,
        "flagged_optional": flagged_opt,
        "missing_required": missing_req,
        "n_rows": int(len(df)),
    }


def model_info(bundle: dict = None) -> dict:
    """Version/provenance/metrics of the loaded model -- useful for agent logging."""
    bundle = bundle or load_bundle()
    return {
        "trained_at": bundle["metadata"]["trained_at"],
        "xgboost_version": bundle["metadata"]["xgboost_version"],
        "sklearn_version": bundle["metadata"]["sklearn_version"],
        "n_features": len(bundle["feature_list"]),
        "classes": bundle["classes_name"],
        "required_curves": bundle["required_curves"],
        "optional_curves": bundle["optional_curves"],
        "test_metrics": bundle["metrics"]["test"],
    }
