"""Petrologix — lithology prediction from wireline well logs.

Predicts rock type per depth sample from standard log curves, using an XGBoost
model trained on 118 Norwegian Continental Shelf wells (FORCE 2020).

Typical use from a backend service:

    from petrologix import check_distribution, predict_lithology, to_intervals

    report = check_distribution("uploaded_well.csv")
    if report["status"] == "out_of_distribution":
        return report["message"]              # refuse rather than fabricate

    result = predict_lithology("uploaded_well.csv")   # ~10,000 rows, one per sample
    zones = to_intervals(result)                      # ~113 rows, one per zone

Always send `to_intervals()` output to an LLM, never `predict_lithology()` output
— a well is ~10,000 samples (~300k tokens). Keep the per-sample frame for plotting.

The model is trained only on the Norwegian Continental Shelf and does not
reliably detect Chalk, Tuff, Marl or Dolomite. See PETROLOGIX_DOCS.md.
"""
from petrologix.config import (
    ACTIVE_MODEL_VERSION,
    LAS_NULL,
    LITHOLOGY_LABELS,
    MODEL_FEATURES,
    MODELS_DIR,
    NULL_SENTINEL_FLOOR,
    OPTIONAL_CURVES,
    REQUIRED_CURVES,
)
from petrologix.las import read_las, strip_null_sentinels
from petrologix.predict import (
    BUNDLE_PATH,
    MissingCurvesError,
    check_distribution,
    load_bundle,
    model_info,
    predict_lithology,
    prepare_features,
    to_intervals,
)

__version__ = "0.2.1"

__all__ = [
    # inference
    "predict_lithology",
    "to_intervals",
    "check_distribution",
    "model_info",
    "prepare_features",
    "load_bundle",
    "MissingCurvesError",
    "BUNDLE_PATH",
    # LAS ingest
    "read_las",
    "strip_null_sentinels",
    # contract constants
    "REQUIRED_CURVES",
    "OPTIONAL_CURVES",
    "MODEL_FEATURES",
    "LITHOLOGY_LABELS",
    "MODELS_DIR",
    "ACTIVE_MODEL_VERSION",
    "LAS_NULL",
    "NULL_SENTINEL_FLOOR",
    "__version__",
]
