"""Inference-side configuration for the Petrologix lithology model.

This module holds only what is needed to *use* the model. Training-side settings
(raw data paths, split ratios, validation ranges, canonical ETL schema) stay in
`etl/config.py`, which imports from here so the two can never disagree about the
feature contract.

Everything in this file ships inside the wheel.
"""
import os
from pathlib import Path

_PACKAGE_DIR = Path(__file__).resolve().parent
_BUNDLED_MODELS_DIR = _PACKAGE_DIR / "models"          # present in an installed wheel
_REPO_MODELS_DIR = _PACKAGE_DIR.parent / "models"      # present in a source checkout


def _resolve_models_dir() -> Path:
    """Locate model artifacts, working both from a checkout and from a wheel.

    Order: explicit env override -> repo `models/` (development, where train.py
    writes) -> `petrologix/models/` (packaged, where the build stages the shipped
    version). Preferring the repo directory in development means a freshly trained
    model is picked up without rebuilding the wheel.
    """
    override = os.environ.get("PETROLOGIX_MODELS_DIR")
    if override:
        return Path(override)
    if _REPO_MODELS_DIR.exists():
        return _REPO_MODELS_DIR
    return _BUNDLED_MODELS_DIR


MODELS_DIR = _resolve_models_dir()

# Which model version predict.py serves. SERVING pointer only -- it must never
# decide where train.py writes (see etl.config.TRAIN_OUTPUT_VERSION). Those were
# one constant once, and lowering the serving pointer silently redirected a
# training run on top of an older model and destroyed it.
ACTIVE_MODEL_VERSION = "v2"

# ---------------------------------------------------------------------------
# Null handling
# ---------------------------------------------------------------------------
# Declared LAS NULL. lasio normally converts this, but a hand-rolled or
# third-party LAS->CSV conversion may leave it in, and -999.25 would otherwise
# read as a physically plausible measurement.
LAS_NULL = -999.25

# Some LAS files carry NULL sentinels other than the -999.25 they declare
# (-999.9 and -999.0 both appear in this dataset), plus filter artifacts around
# -4500 (SP) and -7429 (DRHO). Any log value this far negative is a sentinel or
# an artifact, not a measurement: resistivity and sonic cannot be negative at
# all, and SP never reaches -900 mV. Treating them as real put 43,822 impossible
# RXO values into training.
#
# This is sentinel recognition, not outlier dropping -- the flag-don't-drop
# policy in validate_features/ still governs genuine outliers.
NULL_SENTINEL_FLOOR = -900.0

# Columns that must never be floored: depth and coordinates carry legitimate
# large negatives.
NON_CURVE_COLUMNS = ("DEPT", "DEPTH_MD", "X_LOC", "Y_LOC", "Z_LOC")

# Columns renamed on the way in.
RENAME_MAP = {"DEPT": "DEPTH_MD"}

# ---------------------------------------------------------------------------
# Model feature contract
# ---------------------------------------------------------------------------
# The production input path is LAS -> CSV (via lasio). A LAS file contains ONLY:
#   DEPT/DEPTH_MD, x_loc/y_loc/z_loc, CALI, MUDWEIGHT, ROP, RDEP, RSHA, RMED,
#   RXO, SP, DTC, NPHI, PEF, GR, RHOB, DRHO, and the two FORCE_2020 label curves.
# Notably absent: GROUP, FORMATION (joined from NPD tables in the Kaggle/parquet
# distributions only) and SGR, BS, DTS, DCAL, RMIC, ROPA.
#
# Every model feature must be derivable from a lasio-converted CSV, or it would
# be silently NaN on every prediction ever made in production.

# Curves an uploaded CSV MUST contain -- predict raises if any are missing.
# Availability across the 118 LAS wells: GR/RDEP/RHOB/NPHI/DTC/CALI 118/118,
# RMED 117, DRHO 114.
REQUIRED_CURVES = ["GR", "RDEP", "RMED", "RHOB", "NPHI", "DTC", "CALI", "DRHO"]

# Used when present, tolerated as NaN when absent. PEF is optional deliberately:
# it exists in only 88/118 LAS wells, and requiring it would cost 27 training
# wells (~268k labeled rows) for a curve XGBoost already handles as missing.
OPTIONAL_CURVES = ["PEF", "RSHA", "RXO", "SP", "ROP"]

ROLLING_STAT_SUFFIXES = ["ROLL_MEAN", "ROLL_STD", "GRADIENT"]
ROLLING_CURVES = ["GR", "RHOB", "NPHI", "DTC"]
RESISTIVITY_RATIO_FEATURES = [
    "RDEP_RMED_RATIO", "RDEP_RSHA_RATIO", "RMED_RSHA_RATIO",
]

# The exact ordered feature vector the model consumes (29 features). Order is
# load-bearing: the saved Booster does no column-name validation, so a reordered
# frame produces silently wrong predictions rather than an error.
MODEL_FEATURES = (
    REQUIRED_CURVES
    + OPTIONAL_CURVES
    + RESISTIVITY_RATIO_FEATURES
    + [f"{c}_{s}" for c in ROLLING_CURVES for s in ROLLING_STAT_SUFFIXES]
    + ["DEPTH_MD_ZSCORE"]
)

# FORCE 2020 lithofacies code -> human-readable name.
LITHOLOGY_LABELS = {
    30000: "Sandstone",
    65030: "Sandstone/Shale",
    65000: "Shale",
    80000: "Marl",
    74000: "Dolomite",
    70000: "Limestone",
    70032: "Chalk",
    88000: "Halite",
    86000: "Anhydrite",
    99000: "Tuff",
    90000: "Coal",
    93000: "Basement",
}
