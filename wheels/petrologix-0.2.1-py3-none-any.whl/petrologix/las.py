"""LAS reading and null handling, shared by the ETL pipeline and the backend.

The backend's LAS->CSV step should call `read_las()` rather than rolling its own
lasio call: the null handling here is exactly what the training data went through,
and a backend that strips nulls differently would feed the model a distribution
it never learned.

`lasio` is imported lazily so the rest of the package works without it -- a
backend that receives CSV uploads directly never needs the LAS dependency.

Facts verified across all 118 FORCE 2020 LAS files (don't re-derive):

* lasio already uppercases curve mnemonics (`X_LOC`, not `x_loc`) and converts
  the declared `-999.25` NULL to NaN.
* Units are consistent across every file (GR gAPI, RHOB g/cm3, RDEP ohm.m, ...),
  so no unit harmonization is needed.
* No file declares a duplicate mnemonic.
* `las.df()` puts DEPT on the index; `reset_index()` makes it a column.
* EVERY file carries both DEPT and DEPTH_MD, where DEPTH_MD is a float-roundoff
  duplicate of DEPT (max difference ~1.2e-4). DEPT is kept as the source of truth.
* LAS files contain no GROUP / FORMATION columns -- those are joined in from NPD
  reference tables in the Kaggle and parquet distributions only.
"""
from pathlib import Path
from typing import Union

import numpy as np
import pandas as pd

from petrologix.config import LAS_NULL, NON_CURVE_COLUMNS, NULL_SENTINEL_FLOOR


def strip_null_sentinels(df: pd.DataFrame) -> pd.DataFrame:
    """Convert declared and undeclared NULL sentinels to NaN.

    Applied to log curves only -- never depth or X/Y/Z_LOC, where large negative
    values are legitimate. See config.NULL_SENTINEL_FLOOR for why the floor exists.
    """
    df = df.replace(LAS_NULL, np.nan)
    curve_cols = [c for c in df.columns
                  if c not in NON_CURVE_COLUMNS and pd.api.types.is_numeric_dtype(df[c])]
    if curve_cols:
        df[curve_cols] = df[curve_cols].mask(df[curve_cols] < NULL_SENTINEL_FLOOR)
    return df


def read_las(path: Union[str, Path]) -> pd.DataFrame:
    """Read one LAS file into a flat DataFrame with DEPT as a column.

    Uppercases column names and applies the same null handling the training data
    received. Requires `lasio` (`pip install lasio`).
    """
    import lasio  # lazy: a CSV-only caller does not need this dependency

    las = lasio.read(str(path))
    df = las.df().reset_index()
    df.columns = [str(c).upper() for c in df.columns]
    return strip_null_sentinels(df)
