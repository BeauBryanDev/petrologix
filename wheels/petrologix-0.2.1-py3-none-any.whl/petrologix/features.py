"""Feature engineering shared by training and inference.

This module is the ONLY place these transforms exist. The ETL pipeline
(`transform/features.py`) and the inference path (`petrologix/predict.py`) both
import from here, so training and serving cannot drift apart -- which is the
single most dangerous failure mode for a deployed model, because it produces
confident wrong answers rather than errors.

Deliberately does NOT impute physical log curves (CALI, GR, RHOB, ...): missing
values are left as NaN so XGBoost's native missing-value handling deals with
them, rather than fabricating signal via mean/median fill.

Training-only feature code (GROUP/FORMATION label encoding) lives in
`transform/features.py` and is not shipped in the wheel -- those columns do not
exist in LAS files and are not model features.
"""
import numpy as np
import pandas as pd

from petrologix.config import ROLLING_CURVES

ROLLING_WINDOW = 5  # rows, i.e. samples along depth within a well

RESISTIVITY_RATIO_PAIRS = [
    ("RDEP", "RMED"),
    ("RDEP", "RSHA"),
    ("RMED", "RSHA"),
]


def _safe_ratio(numerator: pd.Series, denominator: pd.Series) -> pd.Series:
    # Map a zero denominator to NaN rather than letting numpy produce inf: inf
    # survives parquet, survives into XGBoost, and produces garbage splits.
    denom = denominator.replace(0, np.nan)
    return numerator / denom


def add_resistivity_ratios(df: pd.DataFrame) -> pd.DataFrame:
    """Deep/medium/shallow resistivity ratios -- the invasion profile.

    These curves read the same rock at different radial depths. Their ratio
    indicates where drilling mud has displaced formation fluid, which is a
    permeability/porosity signal, and is largely invariant to formation water
    salinity -- so it transfers across wells where a raw resistivity does not.
    """
    df = df.copy()
    for num, den in RESISTIVITY_RATIO_PAIRS:
        df[f"{num}_{den}_RATIO"] = _safe_ratio(df[num], df[den])
    return df


def add_rolling_stats(df: pd.DataFrame) -> pd.DataFrame:
    """Rolling mean/std/gradient per well, over depth order.

    Lithology is textural: shale is high-GR and spiky, clean sandstone is low-GR
    and smooth. The rolling mean denoises, the rolling std captures spikiness
    directly, and the diff marks bed boundaries.

    Sorting by (WELL, DEPTH_MD) is mandatory -- a rolling window is meaningless
    out of depth order -- and the returned frame stays in that order.
    """
    df = df.sort_values(["WELL", "DEPTH_MD"]).reset_index(drop=True)
    grouped = df.groupby("WELL", sort=False)

    for curve in ROLLING_CURVES:
        if curve not in df.columns:
            continue
        # Wells where the curve is entirely absent are not special-cased: the
        # grouped rolling is a no-op over all-NaN and yields NaN, which is the
        # intended "no data" representation (never imputed). The groupby is what
        # keeps a window from spanning two wells.
        df[f"{curve}_ROLL_MEAN"] = grouped[curve].transform(
            lambda s: s.rolling(ROLLING_WINDOW, min_periods=2).mean()
        )
        df[f"{curve}_ROLL_STD"] = grouped[curve].transform(
            lambda s: s.rolling(ROLLING_WINDOW, min_periods=2).std()
        )
        df[f"{curve}_GRADIENT"] = grouped[curve].transform(lambda s: s.diff())

    return df


def add_normalized_depth(df: pd.DataFrame) -> pd.DataFrame:
    """Per-well depth z-score.

    Raw DEPTH_MD is a trap: absolute depth is well-specific, so a tree that
    learns "below 2400 m -> Shale" memorizes one well's stratigraphy. The z-score
    encodes relative position within this well's logged interval, which transfers.
    """
    df = df.copy()
    grouped = df.groupby("WELL")["DEPTH_MD"]
    mean = grouped.transform("mean")
    std = grouped.transform("std").replace(0, np.nan)   # guard a single-row well
    df["DEPTH_MD_ZSCORE"] = (df["DEPTH_MD"] - mean) / std
    return df


def engineer_inference_features(df: pd.DataFrame) -> pd.DataFrame:
    """The three transforms that both training and inference apply, in order."""
    df = add_resistivity_ratios(df)
    df = add_rolling_stats(df)
    df = add_normalized_depth(df)
    return df
